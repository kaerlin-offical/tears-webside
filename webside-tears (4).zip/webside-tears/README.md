
  # Responsive Multi-Page Website

  This is a code bundle for Responsive Multi-Page Website. The original project is available at https://www.figma.com/design/szkVnORs1M3OwXapbUBt7T/Responsive-Multi-Page-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  